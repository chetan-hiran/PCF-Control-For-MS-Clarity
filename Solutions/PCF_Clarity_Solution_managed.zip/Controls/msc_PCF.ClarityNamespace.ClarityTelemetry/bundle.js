/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./ClarityTelemetry/index.ts":
/*!***********************************!*\
  !*** ./ClarityTelemetry/index.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

eval("\n\n/* eslint-disable @typescript-eslint/no-empty-function  */\n/* eslint-disable no-undef  */\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.ClarityTelemetry = void 0;\nvar wcpConsent_1 = __webpack_require__(/*! ./wcpConsent */ \"./ClarityTelemetry/wcpConsent.ts\");\nvar ClarityTelemetry = /** @class */function () {\n  function ClarityTelemetry() {}\n  ClarityTelemetry.prototype.init = function (context, notifyOutputChanged, state, container) {\n    var _a, _b;\n    var headLength = document.getElementsByTagName('head').length;\n    var head = document.getElementsByTagName('head')[headLength - 1];\n    var script = document.createElement('script');\n    script.innerHTML = '(function(c,l,a,r,i,t,y){c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};t=l.createElement(r);t.async=1;t.src=\"https://www.clarity.ms/tag/\"+i;y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);})(window, document, \"clarity\", \"script\", \"' + context.parameters.ClarityProjectID.raw + '\");';\n    head.insertBefore(script, head.firstChild);\n    var scriptConsent = document.createElement('script');\n    scriptConsent.src = \"https://wcpstatic.microsoft.com/mscc/lib/v2/wcp-consent.js\";\n    scriptConsent.setAttribute(\"type\", \"text/javascript\");\n    head.appendChild(scriptConsent);\n    this._Container = document.createElement(\"div\");\n    this._Container.id = \"ClarityDivID\";\n    if (context.parameters.DisplayText != null && context.parameters.DisplayText.raw != null) {\n      this._Container.innerHTML = \"<div>\" + context.parameters.DisplayText.raw + \"</div>\";\n    } else {\n      this._Container.innerHTML = \"<div></div>\";\n    }\n    container.appendChild(this._Container);\n    var lg = document.getElementsByTagName('body').length;\n    var body = document.getElementsByTagName('body')[lg - 1];\n    this._ContainerCookieBanner = document.createElement(\"div\");\n    this._ContainerCookieBanner.id = \"cookie-banner\";\n    var positionValue = (_b = (_a = context.parameters.CookieConsentPositionValue) === null || _a === void 0 ? void 0 : _a.raw) !== null && _b !== void 0 ? _b : 0;\n    if (context.parameters.CookieConsentPosition.raw == \"Top\") {\n      this._ContainerCookieBanner.style.top = positionValue.toString();\n    } else {\n      this._ContainerCookieBanner.style.bottom = positionValue.toString();\n    }\n    this._ContainerCookieBanner.style.position = \"fixed\";\n    body.appendChild(this._ContainerCookieBanner);\n    var id = setInterval(checkForWcpConcent, 100);\n    function checkForWcpConcent() {\n      if (window.WcpConsent) {\n        (0, wcpConsent_1.IntializeWcpConsent)();\n        clearInterval(id);\n      }\n    }\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n  ClarityTelemetry.prototype.updateView = function (context) {\n    // Add code to update control view\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n  ClarityTelemetry.prototype.getOutputs = function () {\n    return {};\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n  ClarityTelemetry.prototype.destroy = function () {\n    // Add code to cleanup control if necessary\n  };\n  return ClarityTelemetry;\n}();\nexports.ClarityTelemetry = ClarityTelemetry;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./ClarityTelemetry/index.ts?");

/***/ }),

/***/ "./ClarityTelemetry/wcpConsent.ts":
/*!****************************************!*\
  !*** ./ClarityTelemetry/wcpConsent.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

eval("\n\n/* eslint-disable no-undef  */\n/* eslint-disable no-debugger  */\nObject.defineProperty(exports, \"__esModule\", ({\n  value: true\n}));\nexports.IntializeWcpConsent = void 0;\n///<reference types=\"@wcp/wcp-consent\" />\n//import \"./wcp-consent.js\";\nvar universal_cookie_1 = __webpack_require__(/*! universal-cookie */ \"./node_modules/universal-cookie/es6/index.js\");\nvar locale = getLocale();\nvar siteConsent;\nvar currentAnalytics = sessionStorage.getItem('isAnalytics') === 'true';\n//alert(\"Hello in other method\");\nfunction IntializeWcpConsent() {\n  // Init method\n  WcpConsent && WcpConsent.init(locale, 'cookie-banner', function (err, _siteConsent) {\n    if (err) {\n      alert(err);\n    } else {\n      siteConsent = _siteConsent;\n      //siteConsent.manageConsent();\n      if (typeof window !== 'undefined') {\n        var wnd = window;\n        wnd['siteConsent'] = siteConsent;\n      }\n      console.log(siteConsent);\n      if (siteConsent === null || siteConsent === void 0 ? void 0 : siteConsent.isConsentRequired) {\n        checkForAnalytics();\n      } else {\n        allowForClarity();\n      }\n    }\n  }, onConsentChanged);\n}\nexports.IntializeWcpConsent = IntializeWcpConsent;\nfunction getLocale() {\n  var locale = localStorage.getItem('locale');\n  if (locale === '' || locale === null) {\n    //default value\n    locale = 'en-us';\n  } else {\n    locale = locale.toLowerCase();\n  }\n  return locale;\n}\n// call back method when consent is changed by user\n/**\r\n * @param newConsent\r\n */\nfunction onConsentChanged(newConsent) {\n  var reload = false;\n  if (currentAnalytics != newConsent.Analytics) {\n    console.log('New Consent:', newConsent);\n    sessionStorage.setItem('isAnalytics', newConsent.Analytics.toString());\n    currentAnalytics = newConsent.Analytics;\n    reload = !newConsent.Analytics;\n  }\n  checkForAnalytics(reload);\n}\n/**\r\n *\r\n */\nfunction allowForClarity() {\n  // allow for Clarity\n  if (typeof window !== 'undefined') {\n    var wnd = window;\n    wnd['clarity']('consent');\n  }\n}\n/**\r\n * @param reload\r\n */\nfunction checkForAnalytics(reload) {\n  if (reload === void 0) {\n    reload = false;\n  }\n  var isAnalytics = siteConsent.getConsentFor(WcpConsent.consentCategories.Analytics);\n  if (isAnalytics) {\n    allowForClarity();\n  } else {\n    setTimeout(function () {\n      // remove Analytics cookies\n      var cookies = new universal_cookie_1.default();\n      cookies.remove('_clck');\n      cookies.remove('_clsk');\n      if (reload) {\n        window.location.reload();\n      }\n    }, 3000);\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./ClarityTelemetry/wcpConsent.ts?");

/***/ }),

/***/ "./node_modules/cookie/index.js":
/*!**************************************!*\
  !*** ./node_modules/cookie/index.js ***!
  \**************************************/
/***/ ((__unused_webpack_module, exports) => {

eval("/*!\n * cookie\n * Copyright(c) 2012-2014 Roman Shtylman\n * Copyright(c) 2015 Douglas Christopher Wilson\n * MIT Licensed\n */\n\n\n\n/**\n * Module exports.\n * @public\n */\nexports.parse = parse;\nexports.serialize = serialize;\n\n/**\n * Module variables.\n * @private\n */\n\nvar decode = decodeURIComponent;\nvar encode = encodeURIComponent;\n\n/**\n * RegExp to match field-content in RFC 7230 sec 3.2\n *\n * field-content = field-vchar [ 1*( SP / HTAB ) field-vchar ]\n * field-vchar   = VCHAR / obs-text\n * obs-text      = %x80-FF\n */\n\nvar fieldContentRegExp = /^[\\u0009\\u0020-\\u007e\\u0080-\\u00ff]+$/;\n\n/**\n * Parse a cookie header.\n *\n * Parse the given cookie header string into an object\n * The object has the various cookies as keys(names) => values\n *\n * @param {string} str\n * @param {object} [options]\n * @return {object}\n * @public\n */\n\nfunction parse(str, options) {\n  if (typeof str !== 'string') {\n    throw new TypeError('argument str must be a string');\n  }\n  var obj = {};\n  var opt = options || {};\n  var pairs = str.split(';');\n  var dec = opt.decode || decode;\n  for (var i = 0; i < pairs.length; i++) {\n    var pair = pairs[i];\n    var index = pair.indexOf('=');\n\n    // skip things that don't look like key=value\n    if (index < 0) {\n      continue;\n    }\n    var key = pair.substring(0, index).trim();\n\n    // only assign once\n    if (undefined == obj[key]) {\n      var val = pair.substring(index + 1, pair.length).trim();\n\n      // quoted values\n      if (val[0] === '\"') {\n        val = val.slice(1, -1);\n      }\n      obj[key] = tryDecode(val, dec);\n    }\n  }\n  return obj;\n}\n\n/**\n * Serialize data into a cookie header.\n *\n * Serialize the a name value pair into a cookie string suitable for\n * http headers. An optional options object specified cookie parameters.\n *\n * serialize('foo', 'bar', { httpOnly: true })\n *   => \"foo=bar; httpOnly\"\n *\n * @param {string} name\n * @param {string} val\n * @param {object} [options]\n * @return {string}\n * @public\n */\n\nfunction serialize(name, val, options) {\n  var opt = options || {};\n  var enc = opt.encode || encode;\n  if (typeof enc !== 'function') {\n    throw new TypeError('option encode is invalid');\n  }\n  if (!fieldContentRegExp.test(name)) {\n    throw new TypeError('argument name is invalid');\n  }\n  var value = enc(val);\n  if (value && !fieldContentRegExp.test(value)) {\n    throw new TypeError('argument val is invalid');\n  }\n  var str = name + '=' + value;\n  if (null != opt.maxAge) {\n    var maxAge = opt.maxAge - 0;\n    if (isNaN(maxAge) || !isFinite(maxAge)) {\n      throw new TypeError('option maxAge is invalid');\n    }\n    str += '; Max-Age=' + Math.floor(maxAge);\n  }\n  if (opt.domain) {\n    if (!fieldContentRegExp.test(opt.domain)) {\n      throw new TypeError('option domain is invalid');\n    }\n    str += '; Domain=' + opt.domain;\n  }\n  if (opt.path) {\n    if (!fieldContentRegExp.test(opt.path)) {\n      throw new TypeError('option path is invalid');\n    }\n    str += '; Path=' + opt.path;\n  }\n  if (opt.expires) {\n    if (typeof opt.expires.toUTCString !== 'function') {\n      throw new TypeError('option expires is invalid');\n    }\n    str += '; Expires=' + opt.expires.toUTCString();\n  }\n  if (opt.httpOnly) {\n    str += '; HttpOnly';\n  }\n  if (opt.secure) {\n    str += '; Secure';\n  }\n  if (opt.sameSite) {\n    var sameSite = typeof opt.sameSite === 'string' ? opt.sameSite.toLowerCase() : opt.sameSite;\n    switch (sameSite) {\n      case true:\n        str += '; SameSite=Strict';\n        break;\n      case 'lax':\n        str += '; SameSite=Lax';\n        break;\n      case 'strict':\n        str += '; SameSite=Strict';\n        break;\n      case 'none':\n        str += '; SameSite=None';\n        break;\n      default:\n        throw new TypeError('option sameSite is invalid');\n    }\n  }\n  return str;\n}\n\n/**\n * Try decoding a string using a decoding function.\n *\n * @param {string} str\n * @param {function} decode\n * @private\n */\n\nfunction tryDecode(str, decode) {\n  try {\n    return decode(str);\n  } catch (e) {\n    return str;\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./node_modules/cookie/index.js?");

/***/ }),

/***/ "./node_modules/universal-cookie/es6/Cookies.js":
/*!******************************************************!*\
  !*** ./node_modules/universal-cookie/es6/Cookies.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var cookie__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! cookie */ \"./node_modules/cookie/index.js\");\n/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./utils */ \"./node_modules/universal-cookie/es6/utils.js\");\nvar __assign = undefined && undefined.__assign || function () {\n  __assign = Object.assign || function (t) {\n    for (var s, i = 1, n = arguments.length; i < n; i++) {\n      s = arguments[i];\n      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];\n    }\n    return t;\n  };\n  return __assign.apply(this, arguments);\n};\n\n\nvar Cookies = /** @class */function () {\n  function Cookies(cookies, options) {\n    var _this = this;\n    this.changeListeners = [];\n    this.HAS_DOCUMENT_COOKIE = false;\n    this.cookies = (0,_utils__WEBPACK_IMPORTED_MODULE_1__.parseCookies)(cookies, options);\n    new Promise(function () {\n      _this.HAS_DOCUMENT_COOKIE = (0,_utils__WEBPACK_IMPORTED_MODULE_1__.hasDocumentCookie)();\n    }).catch(function () {});\n  }\n  Cookies.prototype._updateBrowserValues = function (parseOptions) {\n    if (!this.HAS_DOCUMENT_COOKIE) {\n      return;\n    }\n    this.cookies = cookie__WEBPACK_IMPORTED_MODULE_0__.parse(document.cookie, parseOptions);\n  };\n  Cookies.prototype._emitChange = function (params) {\n    for (var i = 0; i < this.changeListeners.length; ++i) {\n      this.changeListeners[i](params);\n    }\n  };\n  Cookies.prototype.get = function (name, options, parseOptions) {\n    if (options === void 0) {\n      options = {};\n    }\n    this._updateBrowserValues(parseOptions);\n    return (0,_utils__WEBPACK_IMPORTED_MODULE_1__.readCookie)(this.cookies[name], options);\n  };\n  Cookies.prototype.getAll = function (options, parseOptions) {\n    if (options === void 0) {\n      options = {};\n    }\n    this._updateBrowserValues(parseOptions);\n    var result = {};\n    for (var name_1 in this.cookies) {\n      result[name_1] = (0,_utils__WEBPACK_IMPORTED_MODULE_1__.readCookie)(this.cookies[name_1], options);\n    }\n    return result;\n  };\n  Cookies.prototype.set = function (name, value, options) {\n    var _a;\n    if (typeof value === 'object') {\n      value = JSON.stringify(value);\n    }\n    this.cookies = __assign(__assign({}, this.cookies), (_a = {}, _a[name] = value, _a));\n    if (this.HAS_DOCUMENT_COOKIE) {\n      document.cookie = cookie__WEBPACK_IMPORTED_MODULE_0__.serialize(name, value, options);\n    }\n    this._emitChange({\n      name: name,\n      value: value,\n      options: options\n    });\n  };\n  Cookies.prototype.remove = function (name, options) {\n    var finalOptions = options = __assign(__assign({}, options), {\n      expires: new Date(1970, 1, 1, 0, 0, 1),\n      maxAge: 0\n    });\n    this.cookies = __assign({}, this.cookies);\n    delete this.cookies[name];\n    if (this.HAS_DOCUMENT_COOKIE) {\n      document.cookie = cookie__WEBPACK_IMPORTED_MODULE_0__.serialize(name, '', finalOptions);\n    }\n    this._emitChange({\n      name: name,\n      value: undefined,\n      options: options\n    });\n  };\n  Cookies.prototype.addChangeListener = function (callback) {\n    this.changeListeners.push(callback);\n  };\n  Cookies.prototype.removeChangeListener = function (callback) {\n    var idx = this.changeListeners.indexOf(callback);\n    if (idx >= 0) {\n      this.changeListeners.splice(idx, 1);\n    }\n  };\n  return Cookies;\n}();\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Cookies);\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./node_modules/universal-cookie/es6/Cookies.js?");

/***/ }),

/***/ "./node_modules/universal-cookie/es6/index.js":
/*!****************************************************!*\
  !*** ./node_modules/universal-cookie/es6/index.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _Cookies__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Cookies */ \"./node_modules/universal-cookie/es6/Cookies.js\");\n\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_Cookies__WEBPACK_IMPORTED_MODULE_0__[\"default\"]);\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./node_modules/universal-cookie/es6/index.js?");

/***/ }),

/***/ "./node_modules/universal-cookie/es6/utils.js":
/*!****************************************************!*\
  !*** ./node_modules/universal-cookie/es6/utils.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"cleanCookies\": () => (/* binding */ cleanCookies),\n/* harmony export */   \"hasDocumentCookie\": () => (/* binding */ hasDocumentCookie),\n/* harmony export */   \"isParsingCookie\": () => (/* binding */ isParsingCookie),\n/* harmony export */   \"parseCookies\": () => (/* binding */ parseCookies),\n/* harmony export */   \"readCookie\": () => (/* binding */ readCookie)\n/* harmony export */ });\n/* harmony import */ var cookie__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! cookie */ \"./node_modules/cookie/index.js\");\n\nfunction hasDocumentCookie() {\n  // Can we get/set cookies on document.cookie?\n  return typeof document === 'object' && typeof document.cookie === 'string';\n}\nfunction cleanCookies() {\n  document.cookie.split(';').forEach(function (c) {\n    document.cookie = c.replace(/^ +/, '').replace(/=.*/, '=;expires=' + new Date().toUTCString() + ';path=/');\n  });\n}\nfunction parseCookies(cookies, options) {\n  if (typeof cookies === 'string') {\n    return cookie__WEBPACK_IMPORTED_MODULE_0__.parse(cookies, options);\n  } else if (typeof cookies === 'object' && cookies !== null) {\n    return cookies;\n  } else {\n    return {};\n  }\n}\nfunction isParsingCookie(value, doNotParse) {\n  if (typeof doNotParse === 'undefined') {\n    // We guess if the cookie start with { or [, it has been serialized\n    doNotParse = !value || value[0] !== '{' && value[0] !== '[' && value[0] !== '\"';\n  }\n  return !doNotParse;\n}\nfunction readCookie(value, options) {\n  if (options === void 0) {\n    options = {};\n  }\n  var cleanValue = cleanupCookieValue(value);\n  if (isParsingCookie(cleanValue, options.doNotParse)) {\n    try {\n      return JSON.parse(cleanValue);\n    } catch (e) {\n      // At least we tried\n    }\n  }\n  // Ignore clean value if we failed the deserialization\n  // It is not relevant anymore to trim those values\n  return value;\n}\nfunction cleanupCookieValue(value) {\n  // express prepend j: before serializing a cookie\n  if (value && value[0] === 'j' && value[1] === ':') {\n    return value.substr(2);\n  }\n  return value;\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./node_modules/universal-cookie/es6/utils.js?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = __webpack_require__("./ClarityTelemetry/index.ts");
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('PCF.ClarityNamespace.ClarityTelemetry', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ClarityTelemetry);
} else {
	var PCF = PCF || {};
	PCF.ClarityNamespace = PCF.ClarityNamespace || {};
	PCF.ClarityNamespace.ClarityTelemetry = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ClarityTelemetry;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}